<article class="product-card">
    <a href="<?php echo e(route('product.details', $item->id)); ?>">
        <div class="img-wrap">
            <span class="badge">New</span>

            <button class="wishlist" aria-label="Wishlist">
                ♡
            </button>
            <?php if($item->image): ?>
                <img src="<?php echo e(asset("$item->image")); ?>" alt="<?php echo e($item->name); ?> Image">
            <?php else: ?>
                <img src="https://placehold.net/product-400x400.png" alt="Placeholder">
            <?php endif; ?>
        </div>

        <div class="stock">
            <span class="dot"></span>
            In stock · <?php echo e($item->quantity); ?> items
        </div>

        <div class="name">
            <?php echo e($item->name); ?>

        </div>

        <div class="price">
            <span class="now">$<?php echo e($item->price); ?></span>
        </div>

        <div class="stars">
            ★★★★★
            <span class="count">(56)</span>
        </div>
    </a>

    <a href="javascript:void(0)" onclick="addToCart(<?php echo e($item->id); ?>,'<?php echo e($item->name); ?>',<?php echo e($item->price); ?>,'<?php echo e($item->image ?? ''); ?>')" class="btn">
        Add to Cart →
    </a>
    

</article>
<?php /**PATH G:\Asia-70\Laravel\lara-project-api\resources\views/components/site/product-card.blade.php ENDPATH**/ ?>