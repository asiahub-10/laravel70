<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description"
        content="Sprylo is a free modern HTML template for tech and electronics stores — multi-color bento hero, indigo primary palette, Plus Jakarta + Outfit + Roboto Mono pair, 5 fully responsive pages, no framework, no build step." />
    <meta name="theme-color" content="#4F46E5" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&family=Outfit:wght@400;500;600;700&family=Roboto+Mono:wght@400;500&display=swap" />
    <link rel="stylesheet" href=<?php echo e(asset('assets-site/css/styles.css')); ?> />
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>
    <a class="skip-link" href="#main">Skip to content</a>

    <!-- Top utility strip -->
    <div class="utility">
        <div class="container">
            <span class="promo">
                <span class="tag">SALE</span>
                Free shipping on orders over $50 · 30-day returns
            </span>
            <span class="links">
                <a href="#">Track order</a>
                <a href="#">Help</a>
                <a href="#">EN · USD</a>
            </span>
        </div>
    </div>

    <?php echo $__env->make('site.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('site.layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('site.layouts.mobile-drawer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('site.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src=<?php echo e(asset('assets-site/js/main.js')); ?> defer></script>
    <script src=<?php echo e(asset('helpers/cart-helper.js')); ?>></script>
    <script>
        const cart = new CartHelper('laraCart');
        function addToCart(id,name,price,img) {
            cart.addItem(id,name,price,img);
            printItemsNumber();
        }
        // console.log(cart.countItems());
        function printItemsNumber(){
            document.querySelector('.icon-btn--cart .count').innerText = cart.countItems();
        }
        printItemsNumber();
    </script>

    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH G:\Asia-70\Laravel\lara-project-api\resources\views/site/layouts/master.blade.php ENDPATH**/ ?>